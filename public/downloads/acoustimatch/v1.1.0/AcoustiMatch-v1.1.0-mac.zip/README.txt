AcoustiMatch - Acoustic Tone Matching
======================================

This package contains three formats of AcoustiMatch:

  AcoustiMatch.app        Standalone application
  AcoustiMatch.component  AU plugin (Logic Pro)
  AcoustiMatch.vst3       VST3 plugin (Ableton, Reaper, etc.)

Installation
------------

Standalone:
  Drag AcoustiMatch.app to /Applications.

AU Plugin (Logic Pro):
  Copy AcoustiMatch.component to:
    ~/Library/Audio/Plug-Ins/Components/

VST3 Plugin:
  Copy AcoustiMatch.vst3 to:
    ~/Library/Audio/Plug-Ins/VST3/

After installing plugins, restart your DAW to scan for new plugins.

License
-------

By installing or using AcoustiMatch you agree to the AcoustiMatch License
Agreement in LICENSE.txt. The app asks you to accept it on first launch.
Third-party components are listed in THIRD-PARTY-NOTICES.txt.

Beta
----

This is a free beta. If you try it, we'd love to hear how the IRs sound on
your rig: use "Send feedback" in the About window (the ... menu), or visit
https://www.molinellomusic.com/contact/

Support: support@molinellomusic.com

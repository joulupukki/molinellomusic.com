AcoustiMatch - Acoustic Tone Matching
======================================

This package contains two formats of AcoustiMatch for Windows:

  AcoustiMatch.exe    Standalone application
  AcoustiMatch.vst3   VST3 plugin (Ableton, Reaper, FL Studio, etc.)

Installation
------------

Standalone:
  Run AcoustiMatch.exe directly, or move it wherever you like.

VST3 Plugin:
  Copy the AcoustiMatch.vst3 folder to:
    C:\Program Files\Common Files\VST3\

  After installing, restart your DAW to scan for new plugins.

How to use it: see "AcoustiMatch User Guide.pdf", or
https://www.molinellomusic.com/software/acoustimatch/

Note: These binaries are not code-signed. Windows SmartScreen may show
a warning on first run. Click "More info" then "Run anyway" to proceed.

License
-------

By installing or using AcoustiMatch you agree to the AcoustiMatch License
Agreement in LICENSE.txt. The app asks you to accept it on first launch.
Third-party components are listed in THIRD-PARTY-NOTICES.txt.

Beta
----

This is a free beta. If you try it, we'd love to hear how the IRs sound on
your rig: use "Send feedback" in the About window (the ... menu), or visit
https://www.molinellomusic.com/contact/

Support: support@molinellomusic.com

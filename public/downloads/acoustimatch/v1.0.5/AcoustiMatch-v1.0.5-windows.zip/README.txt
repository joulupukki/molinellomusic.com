AcoustiMatch - Acoustic Tone Matching
======================================

This package contains two formats of AcoustiMatch for Windows:

  AcoustiMatch.exe    Standalone application
  AcoustiMatch.vst3   VST3 plugin (Ableton, Reaper, FL Studio, etc.)

Installation
------------

Standalone:
  Run AcoustiMatch.exe directly, or move it wherever you like.

VST3 Plugin:
  Copy the AcoustiMatch.vst3 folder to:
    C:\Program Files\Common Files\VST3\

  After installing, restart your DAW to scan for new plugins.

Note: These binaries are not code-signed. Windows SmartScreen may show
a warning on first run. Click "More info" then "Run anyway" to proceed.

Licensing
---------

AcoustiMatch is free to use for training and previewing tone corrections.
Exporting the correction as an impulse response (IR) requires a license key.

To enter your license key, click the "?" button in the toolbar, then click
"Enter License" in the About dialog.

Support: support@molinellomusic.com

AcoustiMatch - Acoustic Tone Matching
======================================

This package contains three formats of AcoustiMatch:

  AcoustiMatch.app        Standalone application
  AcoustiMatch.component  AU plugin (Logic Pro)
  AcoustiMatch.vst3       VST3 plugin (Ableton, Reaper, etc.)

Installation
------------

Standalone:
  Drag AcoustiMatch.app to /Applications.

AU Plugin (Logic Pro):
  Copy AcoustiMatch.component to:
    ~/Library/Audio/Plug-Ins/Components/

VST3 Plugin:
  Copy AcoustiMatch.vst3 to:
    ~/Library/Audio/Plug-Ins/VST3/

After installing plugins, restart your DAW to scan for new plugins.

Licensing
---------

AcoustiMatch is free to use for training and previewing tone corrections.
Exporting the correction as an impulse response (IR) requires a license key.

To enter your license key, click the "?" button in the toolbar, then click
"Enter License" in the About dialog.

Support: support@molinellomusic.com
